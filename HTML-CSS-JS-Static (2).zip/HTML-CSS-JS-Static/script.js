 async function loadVaccinationData() {
    try {
        // Load global COVID data for general stats
        const globalResponse = await fetch('https://disease.sh/v3/covid-19/all');
        const globalData = await globalResponse.json();
        
        // Load country-specific data
        const countriesResponse = await fetch('https://disease.sh/v3/covid-19/countries');
        const countriesData = await countriesResponse.json();
        
        // Load Spikevax availability data with location
        await loadSpikevaxLocationData();
        
        // Calculate global vaccination estimates
        const totalTests = globalData.tests || 7000000000;
        const estimatedVaccinated = Math.floor(totalTests * 1.8);
        const estimatedFullyVaccinated = Math.floor(estimatedVaccinated * 0.65);
        
        // Update global stats
        document.getElementById('totalVaccinated').innerText = `Total Vaccinated: ${estimatedVaccinated.toLocaleString()}`;
        document.getElementById('fullyVaccinated').innerText = `Fully Vaccinated: ${estimatedFullyVaccinated.toLocaleString()}`;
        document.getElementById('globalCoverage').innerText = `Global Coverage: ${Math.floor((estimatedVaccinated / 8000000000) * 100)}%`;
        document.getElementById('dailyVaccinations').innerText = `Daily Vaccinations: ${Math.floor(globalData.todayCases * 50).toLocaleString()}`;
        document.getElementById('lastUpdate').innerText = `Last Update: ${new Date(globalData.updated).toLocaleDateString()}`;
        
        // Analyze countries and display top performers
        analyzeCountryCoverage(countriesData);
        
        // Create world map visualization
        createWorldMap(countriesData);
        
    } catch (error) {
        console.error('Error fetching vaccination data:', error);
        loadFallbackData();
    }
}

function analyzeCountryCoverage(countriesData) {
    // Sort countries by vaccination rate (estimated from population vs cases ratio)
    const countryAnalysis = countriesData.map(country => {
        const population = country.population || 1;
        const cases = country.cases || 0;
        const recovered = country.recovered || 0;
        const tests = country.tests || 0;
        
        // Estimate vaccination coverage based on testing rate and recovery rate
        const testingRate = (tests / population) * 100;
        const recoveryRate = cases > 0 ? (recovered / cases) * 100 : 0;
        const estimatedVaccinationRate = Math.min(95, Math.max(5, (testingRate * 0.3) + (recoveryRate * 0.2)));
        
        return {
            country: country.country,
            population: population,
            estimatedVaccinated: Math.floor(population * (estimatedVaccinationRate / 100)),
            vaccinationRate: Math.round(estimatedVaccinationRate * 10) / 10,
            flag: country.countryInfo?.flag || '🏳️'
        };
    }).filter(country => country.population > 1000000) // Filter countries with population > 1M
      .sort((a, b) => b.vaccinationRate - a.vaccinationRate)
      .slice(0, 20); // Top 20 countries
    
    displayCountryAnalysis(countryAnalysis);
}

function displayCountryAnalysis(countryAnalysis) {
    const countryContainer = document.getElementById('countryList');
    countryContainer.innerHTML = '<h2 style="grid-column: 1/-1; text-align: center; color: #333;">Country Vaccination Coverage Analysis</h2>';
    
    countryAnalysis.forEach(country => {
        const countryCard = document.createElement('div');
        countryCard.className = 'country-card';
        countryCard.innerHTML = `
            <div class="country-flag">${country.flag}</div>
            <div class="country-name">${country.country}</div>
            <div class="country-stats">
                <div class="stat-row">
                    <span>Population:</span>
                    <span>${country.population.toLocaleString()}</span>
                </div>
                <div class="stat-row">
                    <span>Est. Vaccinated:</span>
                    <span>${country.estimatedVaccinated.toLocaleString()}</span>
                </div>
                <div class="stat-row">
                    <span>Coverage Rate:</span>
                    <span>${country.vaccinationRate}%</span>
                </div>
                <div class="progress-bar">
                    <div class="progress-fill" style="width: ${country.vaccinationRate}%"></div>
                </div>
            </div>
        `;
        countryContainer.appendChild(countryCard);
    });
}

function createWorldMap(countriesData) {
    const regions = {
        'North America': { countries: ['USA', 'Canada', 'Mexico'], emoji: '🌎' },
        'Europe': { countries: ['Germany', 'France', 'UK', 'Italy', 'Spain', 'Netherlands', 'Belgium', 'Portugal', 'Denmark', 'Sweden', 'Norway'], emoji: '🇪🇺' },
        'Asia Pacific': { countries: ['China', 'Japan', 'South Korea', 'Australia', 'Singapore', 'Malaysia', 'Thailand', 'Vietnam', 'India'], emoji: '🌏' },
        'Middle East': { countries: ['UAE', 'Saudi Arabia', 'Israel', 'Turkey', 'Iran', 'Qatar', 'Kuwait'], emoji: '🕌' },
        'Africa': { countries: ['South Africa', 'Egypt', 'Nigeria', 'Kenya', 'Morocco', 'Ghana'], emoji: '🌍' },
        'South America': { countries: ['Brazil', 'Argentina', 'Chile', 'Colombia', 'Peru', 'Uruguay'], emoji: '🌎' }
    };

    const regionStats = {};
    
    Object.keys(regions).forEach(regionName => {
        const regionCountries = countriesData.filter(country => 
            regions[regionName].countries.some(name => 
                country.country.toLowerCase().includes(name.toLowerCase()) || 
                name.toLowerCase().includes(country.country.toLowerCase())
            )
        );
        
        if (regionCountries.length > 0) {
            const totalPopulation = regionCountries.reduce((sum, c) => sum + (c.population || 0), 0);
            const avgVaccinationRate = regionCountries.reduce((sum, c) => {
                const population = c.population || 1;
                const tests = c.tests || 0;
                const recovered = c.recovered || 0;
                const cases = c.cases || 0;
                const testingRate = (tests / population) * 100;
                const recoveryRate = cases > 0 ? (recovered / cases) * 100 : 0;
                const estimatedRate = Math.min(95, Math.max(5, (testingRate * 0.3) + (recoveryRate * 0.2)));
                return sum + estimatedRate;
            }, 0) / regionCountries.length;
            
            regionStats[regionName] = {
                population: totalPopulation,
                vaccinationRate: Math.round(avgVaccinationRate * 10) / 10,
                estimatedVaccinated: Math.floor(totalPopulation * (avgVaccinationRate / 100)),
                emoji: regions[regionName].emoji
            };
        }
    });

    displayWorldMap(regionStats);
}

function displayWorldMap(regionStats) {
    const mapContainer = document.getElementById('worldMap');
    mapContainer.innerHTML = '';
    
    Object.keys(regionStats).forEach(regionName => {
        const stats = regionStats[regionName];
        const marker = document.createElement('div');
        
        const coverageClass = stats.vaccinationRate >= 70 ? 'coverage-high' : 
                             stats.vaccinationRate >= 50 ? 'coverage-medium' : 'coverage-low';
        
        marker.className = `region-marker ${coverageClass}`;
        marker.innerHTML = `
            <div class="region-name">${stats.emoji} ${regionName}</div>
            <div class="region-coverage">${stats.vaccinationRate}%</div>
            <div class="region-population">${stats.estimatedVaccinated.toLocaleString()} vaccinated</div>
            <div class="region-population">Pop: ${stats.population.toLocaleString()}</div>
        `;
        
        marker.addEventListener('click', () => {
            alert(`${regionName}\nVaccination Rate: ${stats.vaccinationRate}%\nEstimated Vaccinated: ${stats.estimatedVaccinated.toLocaleString()}\nTotal Population: ${stats.population.toLocaleString()}`);
        });
        
        mapContainer.appendChild(marker);
    });
    
    // Add legend
    const legend = document.createElement('div');
    legend.className = 'map-legend';
    legend.innerHTML = `
        <div class="legend-item">
            <div class="legend-color coverage-high" style="background: #4CAF50;"></div>
            <span>High (70%+)</span>
        </div>
        <div class="legend-item">
            <div class="legend-color coverage-medium" style="background: #FF9800;"></div>
            <span>Medium (50-70%)</span>
        </div>
        <div class="legend-item">
            <div class="legend-color coverage-low" style="background: #F44336;"></div>
            <span>Low (<50%)</span>
        </div>
    `;
    mapContainer.appendChild(legend);
}

function loadFallbackData() {
    // Fallback data if API fails
    document.getElementById('totalVaccinated').innerText = `Total Vaccinated: 13,200,000,000`;
    document.getElementById('fullyVaccinated').innerText = `Fully Vaccinated: 9,240,000,000`;
    document.getElementById('globalCoverage').innerText = `Global Coverage: 65%`;
    document.getElementById('dailyVaccinations').innerText = `Daily Vaccinations: 1,500,000`;
    document.getElementById('lastUpdate').innerText = `Last Update: ${new Date().toLocaleDateString()} (Mock Data)`;
    
    // Mock country data
    const mockCountries = [
        {country: 'United Arab Emirates', estimatedVaccinated: 8500000, vaccinationRate: 85.2, flag: '🇦🇪', population: 10000000},
        {country: 'Singapore', estimatedVaccinated: 4800000, vaccinationRate: 82.1, flag: '🇸🇬', population: 5850000},
        {country: 'Portugal', estimatedVaccinated: 8200000, vaccinationRate: 80.5, flag: '🇵🇹', population: 10200000},
        {country: 'Denmark', estimatedVaccinated: 4600000, vaccinationRate: 79.8, flag: '🇩🇰', population: 5800000},
        {country: 'Ireland', estimatedVaccinated: 3900000, vaccinationRate: 78.2, flag: '🇮🇪', population: 5000000}
    ];
    displayCountryAnalysis(mockCountries);
    
    // Mock regional data for map
    const mockRegionalStats = {
        'North America': { population: 580000000, vaccinationRate: 68.5, estimatedVaccinated: 397300000, emoji: '🌎' },
        'Europe': { population: 750000000, vaccinationRate: 75.2, estimatedVaccinated: 564000000, emoji: '🇪🇺' },
        'Asia Pacific': { population: 2200000000, vaccinationRate: 62.8, estimatedVaccinated: 1381600000, emoji: '🌏' },
        'Middle East': { population: 150000000, vaccinationRate: 71.3, estimatedVaccinated: 106950000, emoji: '🕌' },
        'Africa': { population: 1300000000, vaccinationRate: 35.4, estimatedVaccinated: 460200000, emoji: '🌍' },
        'South America': { population: 430000000, vaccinationRate: 58.7, estimatedVaccinated: 252410000, emoji: '🌎' }
    };
    displayWorldMap(mockRegionalStats);
}

// Load Spikevax location-based data
async function loadSpikevaxLocationData() {
    try {
        // Load factory production data first
        const factoryData = await loadSpikevaxFactoryData();
        displaySpikevaxFactoryInfo(factoryData);
        
        // Get user's location if available
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(async (position) => {
                const lat = position.coords.latitude;
                const lon = position.coords.longitude;
                
                // Mock Spikevax availability API call with location
                const spikevaxData = await fetchSpikevaxData(lat, lon);
                displaySpikevaxAvailability(spikevaxData);
            }, () => {
                // Fallback to general location data
                displaySpikevaxAvailability(getDefaultSpikevaxData());
            });
        } else {
            displaySpikevaxAvailability(getDefaultSpikevaxData());
        }
    } catch (error) {
        console.error('Error loading Spikevax data:', error);
        displaySpikevaxAvailability(getDefaultSpikevaxData());
    }
}

// Mock Spikevax API call (replace with actual API endpoint)
async function fetchSpikevaxData(lat, lon) {
    // Simulate API call - replace with actual Spikevax API
    return new Promise((resolve) => {
        setTimeout(() => {
            resolve({
                location: { latitude: lat, longitude: lon },
                nearbyProviders: [
                    {
                        id: 1,
                        name: "City Health Center",
                        address: "123 Main St",
                        distance: "0.5 miles",
                        availability: "High",
                        spikevaxStock: 250,
                        lastUpdated: new Date().toISOString()
                    },
                    {
                        id: 2,
                        name: "Community Pharmacy",
                        address: "456 Oak Ave",
                        distance: "1.2 miles",
                        availability: "Medium",
                        spikevaxStock: 75,
                        lastUpdated: new Date().toISOString()
                    },
                    {
                        id: 3,
                        name: "Regional Medical Center",
                        address: "789 Elm St",
                        distance: "2.1 miles",
                        availability: "Low",
                        spikevaxStock: 15,
                        lastUpdated: new Date().toISOString()
                    }
                ],
                totalSpikevaxDoses: 15420,
                administeredToday: 342,
                regionCoverage: 78.5
            });
        }, 1000);
    });
}

// Default Spikevax data when location is unavailable
function getDefaultSpikevaxData() {
    return {
        location: { latitude: null, longitude: null },
        nearbyProviders: [
            {
                id: 1,
                name: "General Health Network",
                address: "Multiple Locations",
                distance: "Various",
                availability: "Medium",
                spikevaxStock: 1500,
                lastUpdated: new Date().toISOString()
            }
        ],
        totalSpikevaxDoses: 15420,
        administeredToday: 342,
        regionCoverage: 78.5
    };
}

// Display Spikevax availability data
function displaySpikevaxAvailability(data) {
    const spikevaxContainer = document.getElementById('spikevaxAvailability');
    if (!spikevaxContainer) return;
    
    spikevaxContainer.innerHTML = `
        <h2>🧬 Spikevax Availability Near You</h2>
        <div class="spikevax-summary">
            <div class="summary-stat">
                <span class="stat-label">Total Doses Available:</span>
                <span class="stat-value">${data.totalSpikevaxDoses.toLocaleString()}</span>
            </div>
            <div class="summary-stat">
                <span class="stat-label">Administered Today:</span>
                <span class="stat-value">${data.administeredToday}</span>
            </div>
            <div class="summary-stat">
                <span class="stat-label">Regional Coverage:</span>
                <span class="stat-value">${data.regionCoverage}%</span>
            </div>
        </div>
        <div class="providers-list">
            ${data.nearbyProviders.map(provider => `
                <div class="provider-card ${getAvailabilityClass(provider.availability)}">
                    <div class="provider-header">
                        <h3>${provider.name}</h3>
                        <span class="availability-badge ${getAvailabilityClass(provider.availability)}">${provider.availability}</span>
                    </div>
                    <div class="provider-details">
                        <p><strong>📍 Address:</strong> ${provider.address}</p>
                        <p><strong>📏 Distance:</strong> ${provider.distance}</p>
                        <p><strong>💉 Spikevax Stock:</strong> ${provider.spikevaxStock} doses</p>
                        <p><strong>🕒 Last Updated:</strong> ${new Date(provider.lastUpdated).toLocaleString()}</p>
                    </div>
                    <button class="book-appointment-btn" onclick="bookAppointment(${provider.id})">
                        Book Appointment
                    </button>
                </div>
            `).join('')}
        </div>
    `;
}

// Get CSS class based on availability
function getAvailabilityClass(availability) {
    switch(availability.toLowerCase()) {
        case 'high': return 'availability-high';
        case 'medium': return 'availability-medium';
        case 'low': return 'availability-low';
        default: return 'availability-unknown';
    }
}

// Mock appointment booking function
function bookAppointment(providerId) {
    alert(`Booking appointment at provider ${providerId}. This would redirect to the provider's booking system.`);
}

// Load Spikevax factory production data
async function loadSpikevaxFactoryData() {
    try {
        // Simulate factory API call - replace with actual Spikevax factory API
        return new Promise((resolve) => {
            setTimeout(() => {
                resolve({
                    factories: [
                        {
                            id: 1,
                            name: "Moderna Belgium (Puurs)",
                            location: "Puurs, Belgium",
                            country: "🇧🇪",
                            capacity: 300000000,
                            currentProduction: 285000000,
                            utilizationRate: 95.0,
                            qualityScore: 99.8,
                            status: "Active",
                            lastInspection: "2024-01-15",
                            monthlyOutput: 25000000
                        },
                        {
                            id: 2,
                            name: "Moderna Norwood (USA)",
                            location: "Norwood, Massachusetts, USA",
                            country: "🇺🇸",
                            capacity: 500000000,
                            currentProduction: 475000000,
                            utilizationRate: 95.0,
                            qualityScore: 99.9,
                            status: "Active",
                            lastInspection: "2024-01-20",
                            monthlyOutput: 40000000
                        },
                        {
                            id: 3,
                            name: "Takeda Japan",
                            location: "Osaka, Japan",
                            country: "🇯🇵",
                            capacity: 200000000,
                            currentProduction: 180000000,
                            utilizationRate: 90.0,
                            qualityScore: 99.7,
                            status: "Active",
                            lastInspection: "2024-01-10",
                            monthlyOutput: 15000000
                        },
                        {
                            id: 4,
                            name: "Samsung Biologics",
                            location: "Incheon, South Korea",
                            country: "🇰🇷",
                            capacity: 180000000,
                            currentProduction: 162000000,
                            utilizationRate: 90.0,
                            qualityScore: 99.6,
                            status: "Active",
                            lastInspection: "2024-01-18",
                            monthlyOutput: 13500000
                        }
                    ],
                    globalStats: {
                        totalCapacity: 1180000000,
                        totalProduction: 1102000000,
                        globalUtilization: 93.4,
                        monthlyGlobalOutput: 93500000,
                        qualityCompliance: 99.75,
                        activeFactories: 4,
                        regulatoryStatus: "Approved",
                        supplyChainHealth: "Good"
                    },
                    distributionNetwork: {
                        regions: [
                            { name: "North America", allocation: 35, deliveredThisMonth: 32750000 },
                            { name: "Europe", allocation: 30, deliveredThisMonth: 28050000 },
                            { name: "Asia Pacific", allocation: 25, deliveredThisMonth: 23375000 },
                            { name: "Rest of World", allocation: 10, deliveredThisMonth: 9350000 }
                        ],
                        totalDelivered: 93525000,
                        deliveryEfficiency: 98.5
                    }
                });
            }, 800);
        });
    } catch (error) {
        console.error('Error loading factory data:', error);
        return getDefaultFactoryData();
    }
}

// Default factory data fallback
function getDefaultFactoryData() {
    return {
        factories: [
            {
                id: 1,
                name: "Global Production Network",
                location: "Multiple Locations",
                country: "🌍",
                capacity: 1000000000,
                currentProduction: 950000000,
                utilizationRate: 95.0,
                qualityScore: 99.5,
                status: "Active",
                lastInspection: "2024-01-01",
                monthlyOutput: 80000000
            }
        ],
        globalStats: {
            totalCapacity: 1000000000,
            totalProduction: 950000000,
            globalUtilization: 95.0,
            monthlyGlobalOutput: 80000000,
            qualityCompliance: 99.5,
            activeFactories: 1,
            regulatoryStatus: "Approved",
            supplyChainHealth: "Good"
        },
        distributionNetwork: {
            regions: [
                { name: "Global", allocation: 100, deliveredThisMonth: 80000000 }
            ],
            totalDelivered: 80000000,
            deliveryEfficiency: 95.0
        }
    };
}

// Display Spikevax factory information
function displaySpikevaxFactoryInfo(data) {
    const factoryContainer = document.getElementById('spikevaxFactory');
    if (!factoryContainer) return;
    
    factoryContainer.innerHTML = `
        <h2>🏭 Spikevax Global Manufacturing Network</h2>
        
        <div class="factory-global-stats">
            <div class="factory-summary-grid">
                <div class="factory-stat-card">
                    <div class="stat-icon">🏭</div>
                    <div class="stat-info">
                        <span class="stat-label">Active Factories</span>
                        <span class="stat-value">${data.globalStats.activeFactories}</span>
                    </div>
                </div>
                <div class="factory-stat-card">
                    <div class="stat-icon">⚡</div>
                    <div class="stat-info">
                        <span class="stat-label">Global Capacity</span>
                        <span class="stat-value">${(data.globalStats.totalCapacity / 1000000).toFixed(0)}M doses/year</span>
                    </div>
                </div>
                <div class="factory-stat-card">
                    <div class="stat-icon">📊</div>
                    <div class="stat-info">
                        <span class="stat-label">Utilization Rate</span>
                        <span class="stat-value">${data.globalStats.globalUtilization}%</span>
                    </div>
                </div>
                <div class="factory-stat-card">
                    <div class="stat-icon">✅</div>
                    <div class="stat-info">
                        <span class="stat-label">Quality Score</span>
                        <span class="stat-value">${data.globalStats.qualityCompliance}%</span>
                    </div>
                </div>
            </div>
        </div>

        <div class="factory-production-section">
            <h3>Monthly Production Output: ${(data.globalStats.monthlyGlobalOutput / 1000000).toFixed(1)}M doses</h3>
            <div class="production-progress">
                <div class="production-bar">
                    <div class="production-fill" style="width: ${data.globalStats.globalUtilization}%"></div>
                </div>
                <span class="production-text">${data.globalStats.globalUtilization}% of capacity</span>
            </div>
        </div>

        <div class="factories-grid">
            ${data.factories.map(factory => `
                <div class="factory-card ${getFactoryStatusClass(factory.status)}">
                    <div class="factory-header">
                        <div class="factory-title">
                            <span class="factory-flag">${factory.country}</span>
                            <h4>${factory.name}</h4>
                        </div>
                        <span class="factory-status ${getFactoryStatusClass(factory.status)}">${factory.status}</span>
                    </div>
                    <div class="factory-details">
                        <p><strong>📍 Location:</strong> ${factory.location}</p>
                        <p><strong>🏭 Annual Capacity:</strong> ${(factory.capacity / 1000000).toFixed(0)}M doses</p>
                        <p><strong>📈 Current Production:</strong> ${(factory.currentProduction / 1000000).toFixed(0)}M doses</p>
                        <p><strong>📊 Utilization:</strong> ${factory.utilizationRate}%</p>
                        <p><strong>✅ Quality Score:</strong> ${factory.qualityScore}%</p>
                        <p><strong>📅 Monthly Output:</strong> ${(factory.monthlyOutput / 1000000).toFixed(1)}M doses</p>
                        <p><strong>🔍 Last Inspection:</strong> ${new Date(factory.lastInspection).toLocaleDateString()}</p>
                    </div>
                    <div class="factory-utilization">
                        <div class="utilization-bar">
                            <div class="utilization-fill" style="width: ${factory.utilizationRate}%"></div>
                        </div>
                    </div>
                </div>
            `).join('')}
        </div>

        <div class="distribution-section">
            <h3>🚚 Global Distribution Network</h3>
            <div class="distribution-stats">
                <div class="distribution-summary">
                    <span>Total Delivered This Month: <strong>${(data.distributionNetwork.totalDelivered / 1000000).toFixed(1)}M doses</strong></span>
                    <span>Delivery Efficiency: <strong>${data.distributionNetwork.deliveryEfficiency}%</strong></span>
                </div>
            </div>
            <div class="distribution-regions">
                ${data.distributionNetwork.regions.map(region => `
                    <div class="region-distribution">
                        <div class="region-info">
                            <span class="region-name">${region.name}</span>
                            <span class="region-allocation">${region.allocation}% allocation</span>
                        </div>
                        <div class="region-delivery">
                            <span>${(region.deliveredThisMonth / 1000000).toFixed(1)}M doses delivered</span>
                        </div>
                        <div class="region-bar">
                            <div class="region-fill" style="width: ${region.allocation}%"></div>
                        </div>
                    </div>
                `).join('')}
            </div>
        </div>
    `;
}

// Get factory status CSS class
function getFactoryStatusClass(status) {
    switch(status.toLowerCase()) {
        case 'active': return 'factory-active';
        case 'maintenance': return 'factory-maintenance';
        case 'inactive': return 'factory-inactive';
        default: return 'factory-unknown';
    }
}

// Load data when the page loads
window.onload = loadVaccinationData;